var classOnlineMapsBuildingBase =
[
    [ "MetaInfo", "structOnlineMapsBuildingBase_1_1MetaInfo.html", "structOnlineMapsBuildingBase_1_1MetaInfo" ],
    [ "RoofType", "classOnlineMapsBuildingBase.html#a7b68fdef2c1d983da3c2395129b07a9c", [
      [ "dome", "classOnlineMapsBuildingBase.html#a7b68fdef2c1d983da3c2395129b07a9ca1b71c8e9e749753da4e8f55b029ced5f", null ],
      [ "flat", "classOnlineMapsBuildingBase.html#a7b68fdef2c1d983da3c2395129b07a9ca37fc7edee25a177474eaebe7f7b09785", null ]
    ] ],
    [ "CheckIgnoredBuildings", "classOnlineMapsBuildingBase.html#aa19160f809595d2c8d9a399de4396d09", null ],
    [ "CreateGameObject", "classOnlineMapsBuildingBase.html#a6286399493151345aba9aafcbf2e5513", null ],
    [ "Dispose", "classOnlineMapsBuildingBase.html#aed07e1998c9b0fb8e042c9a38df9f97e", null ],
    [ "GetLocalPoints", "classOnlineMapsBuildingBase.html#a639c6bb361103284cbfc44728a938e20", null ],
    [ "LoadMeta", "classOnlineMapsBuildingBase.html#a382a6459e07c68214bbfd0ad7dc1bb2e", null ],
    [ "OnBasePress", "classOnlineMapsBuildingBase.html#acd8d59730b25d6db9cb1dc424e9856fa", null ],
    [ "OnBaseRelease", "classOnlineMapsBuildingBase.html#a5dea7614882bc59f3249cbdd6f494da9", null ],
    [ "OnMouseDown", "classOnlineMapsBuildingBase.html#a003deb39305b14212c82d282c2fcfb8e", null ],
    [ "OnMouseUp", "classOnlineMapsBuildingBase.html#ae2708ce2d64b6827f5cb024b3ca7b80a", null ],
    [ "boundsCoords", "classOnlineMapsBuildingBase.html#a25d1fcd020ddd4522d3d24468a652298", null ],
    [ "buildingCollider", "classOnlineMapsBuildingBase.html#a543ca5e5a3c738714fedb833bfbad941", null ],
    [ "centerCoordinates", "classOnlineMapsBuildingBase.html#a1f2356cdf9c4c97a5700d0e4cf9ab5ad", null ],
    [ "hasErrors", "classOnlineMapsBuildingBase.html#a2abe280321bc480da015d219334a0ce6", null ],
    [ "id", "classOnlineMapsBuildingBase.html#a60d10315ef64ffa4bf27b962fd962f8f", null ],
    [ "initialZoom", "classOnlineMapsBuildingBase.html#af402e6e82769e835ea608380c9844d74", null ],
    [ "metaInfo", "classOnlineMapsBuildingBase.html#a8c36085dfa2c3a7fc0f188acbd4e6d37", null ],
    [ "OnClick", "classOnlineMapsBuildingBase.html#a4c8789cca999dbcfe10e380dc72536c1", null ],
    [ "OnDispose", "classOnlineMapsBuildingBase.html#aa91fc878c86cd3e4e2c6d32edb49e401", null ],
    [ "OnPress", "classOnlineMapsBuildingBase.html#afd8809536a3ea387dcf981b3e37258df", null ],
    [ "OnRelease", "classOnlineMapsBuildingBase.html#a6005b6ebef46767311131ee862dbb390", null ],
    [ "perimeter", "classOnlineMapsBuildingBase.html#a7ba0ff10f5592f5a98814abd2148e0d5", null ]
];